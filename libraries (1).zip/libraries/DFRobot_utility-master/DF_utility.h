//
void fill_uint16_bigend (uint8_t *thebuf, uint16_t data);


//
void fill_uint16 (uint8_t *thebuf, uint16_t data);
