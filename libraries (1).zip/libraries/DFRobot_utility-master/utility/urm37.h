/**************************************************************************/
/*! 
  @file     urm37.h
  @author   lisper (lisper.li@dfrobot.com)
  @license  LGPLv3 (see license.txt) 

  urm37 library use serial

  Copyright (C) DFRobot - www.dfrobot.com
 */
/**************************************************************************/


#include <Arduino.h>
uint16_t urm37GetDist ();

